const path = require('path');

module.exports = {
    mode: 'development',
    entry: './src/main.js', // Entry point of your application
    output: {
        filename: 'bundle.js', // Name of the bundled file
        path: path.resolve(__dirname, 'dist'), // Output directory
    },
    
};
