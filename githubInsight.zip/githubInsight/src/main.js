document.addEventListener("DOMContentLoaded", async function() {
    const usernameInput = document.getElementById("usernameInput");
    let timeoutId; // Variable to store the timeout ID

    const defaultUsername = 'fatimaghalmi';
    const token = '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';
    const defaultProfileUrl = `https://api.github.com/users/${defaultUsername}`;
    const defaultReposUrl = `https://api.github.com/users/${defaultUsername}/repos`;

    let userData; // Store the initial user data
    let repoData; // Store the initial repository data

    try {
        // Fetch initial user profile information
        const profileResponse = await fetch(defaultProfileUrl, {
            headers: {
                Authorization: `token ${token}`
            }
        });
        userData = await profileResponse.json();

        // Update initial user profile information
        document.getElementById("profilphoto").src = userData.avatar_url;
        document.getElementById("name").textContent = userData.login || "Non fourni";
        document.getElementById("followers").innerText = userData.followers;
        document.getElementById("following").innerText = userData.following;
        document.getElementById("publicRepos").innerText = userData.public_repos;

        const joinDate = userData.created_at;
        const currentDate = moment();

        const duration = moment.duration(currentDate.diff(moment(joinDate))).months();
        document.getElementById('githubMembership').innerText = 'GitHub Member for ' + duration + 'Month';

        // Access location inside this promise handler
        if (userData.location) {
            // Extract country from the location
            const country = userData.location.split(" ").pop().toLowerCase();

            // Fetch emojis to get the country flag
            const emojisResponse = await fetch("https://api.github.com/emojis");
            const emojisData = await emojisResponse.json();

            // Check if the country flag exists in the emojis
            if (emojisData.hasOwnProperty(country)) {
                const countryFlagUrl = emojisData[country];
                document.getElementById("flag").src = countryFlagUrl;
            } else {
                console.error("Country flag not found for location:", userData.location);
            }
        }
    } catch (error) {
        console.error('Error fetching user profile information:', error);
    }

    try {
        // Fetch initial user repositories
        const reposResponse = await fetch(defaultReposUrl, {
            headers: {
                Authorization: `token ${token}`
            }
        });
        repoData = await reposResponse.json();

        // Update initial user repositories
        const repositoriesSection = document.getElementById("repostories");
        repositoriesSection.innerHTML = ""; // Clear previous repositories

        repoData.forEach(repo => {
            // Your repository rendering logic here
            const repoContainer = document.createElement("div");
            repoContainer.style.backgroundColor = "#f7fafc";
            repoContainer.style.border = "1px solid #e2e8f0";
            repoContainer.style.borderRadius = "0.5rem";
            repoContainer.style.padding = "1.25rem";
            repoContainer.style.width = "18rem";
            repoContainer.style.height = "7rem";
            repoContainer.style.position = "relative";

            const repoNameLink = document.createElement("a");
            repoNameLink.style.position = "absolute";
            repoNameLink.style.fontSize = "1.25rem";
            repoNameLink.style.color = "#3182ce";
            repoNameLink.style.top = "0.25rem";
            repoNameLink.style.textDecoration = "underline";
            repoNameLink.textContent = repo.name;
            repoNameLink.href = repo.html_url; // Set the URL of the link to redirect to the repository on GitHub

            // Open the link in a new window/tab
            repoNameLink.target = "_blank";

            const repoDescription = document.createElement("p");
            repoDescription.style.fontSize = "0.75rem";
            repoDescription.style.position = "absolute";
            repoDescription.style.marginTop = "1.75rem";
            repoDescription.textContent = repo.description || "Aucune description disponible";

            const repoLanguage = document.createElement("p");
            repoLanguage.style.marginTop = "4rem";
            repoLanguage.style.marginLeft = "0.25rem";
            repoLanguage.style.fontSize = "0.75rem";
            repoLanguage.textContent = repo.language || "Langue non spécifiée";

            repoContainer.appendChild(repoNameLink);
            repoContainer.appendChild(repoDescription);
            repoContainer.appendChild(repoLanguage);

            repositoriesSection.appendChild(repoContainer);
        });
    } catch (error) {
        console.error('Error fetching user repositories:', error);
    }

    // Add event listener to the input field
    usernameInput.addEventListener("keyup", async function() {
        clearTimeout(timeoutId); // Clear previous timeout

        // Set a new timeout to wait for 1 second after the user stops typing
        timeoutId = setTimeout(async () => {
            const enteredUsername = this.value.trim(); // Get the entered username and trim any whitespace

            if (enteredUsername !== "") {
                // Call a function to fetch and update user information based on the entered username
                await fetchAndUpdateUserInfo(enteredUsername);
            } else {
                console.error("Username is empty");
            }
        }, 1000); // 1000 milliseconds (1 second) delay
    });

    // Function to fetch and update user information
    async function fetchAndUpdateUserInfo(username) {
        const reposUrl = `https://api.github.com/users/${username}/repos`;
        const defaultProfileUrl = `https://api.github.com/users/${defaultUsername}`;

        try {
            // Fetch user repositories
            const reposResponse = await fetch(reposUrl, {
                headers: {
                    Authorization: `token ${token}`
                }
            });
            const reposData = await reposResponse.json();

            const repositoriesSection = document.getElementById("repostories");
            repositoriesSection.innerHTML = ""; // Clear previous repositories

            reposData.forEach(repo => {
                // Your repository rendering logic here
            });
        } catch (error) {
            console.error('Error fetching user repositories:', error);
        }

        try {
            // Fetch default user profile information
            const profileResponse = await fetch(defaultProfileUrl, {
                headers: {
                    Authorization: `token ${token}`
                }
            });
            userData = await profileResponse.json();

            // Your logic to update default user profile information here

        } catch (error) {
            console.error('Error fetching default user profile information:', error);
        }
    }

    // Add event listener to the button
    const button = document.querySelector('button');
    button.addEventListener("click", function() {
        // Clear the input field
        usernameInput.value = "";
        // Clear only the user-entered data and repositories
        clearUserAndRepoData();
    });

    // Function to clear only the user-entered data and repositories
    function clearUserAndRepoData() {
        const repositoriesSection = document.getElementById("repostories");
        repositoriesSection.innerHTML = ""; // Clear repositories

        // If there is no user data, use the default user data
        if (!userData) {
            // Fetch and update default user profile information
            fetchAndUpdateUserInfo(defaultUsername);
        } else {
            // Use the default user data
            // Update user profile information with default data
            document.getElementById("profilphoto").src = userData.avatar_url;
            document.getElementById("name").textContent = userData.login || "Non fourni";
            document.getElementById("followers").innerText = userData.followers;
            document.getElementById("following").innerText = userData.following;
            document.getElementById("publicRepos").innerText = userData.public_repos;

            // Access location inside this promise handler
            if (userData.location) {
                // Extract country from the location
                const country = userData.location.split(" ").pop().toLowerCase();

                // Fetch emojis to get the country flag
                fetch("https://api.github.com/emojis")
                    .then(response => response.json())
                    .then(emojisData => {
                        // Check if the country flag exists in the emojis
                        if (emojisData.hasOwnProperty(country)) {
                            const countryFlagUrl = emojisData[country];
                            document.getElementById("flag").src = countryFlagUrl;
                        } else {
                            console.error("Country flag not found for location:", userData.location);
                        }
                    })
                    .catch(error => {
                        console.error("Error fetching emojis:", error);
                    });

                // Calculate GitHub membership duration
            }

            // Update repositories with default data
            repositoriesSection.innerHTML = ""; // Clear repositories
            repoData.forEach(repo => {
                // Your repository rendering logic here
            });
        }
    }

    document.getElementById('back-to-top').addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const toggleButton = document.getElementById('profileInsightsButton');
    const section1 = document.getElementById('repostories');
    const section2 = document.getElementById('repostories2');

    toggleButton.addEventListener('click', function() {
        // Toggle the visibility of the sections
        section1.classList.toggle('hidden');
        section2.classList.toggle('hidden');
    });
});
